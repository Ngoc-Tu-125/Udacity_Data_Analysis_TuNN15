Resources Reference:
https://numpy.org/doc/stable/reference/generated/numpy.append.html
https://numpy.org/doc/stable/reference/random/generated/numpy.random.choice.html
https://data-flair.training/blogs/python-statistics/
https://www.youtube.com/watch?v=0CiMDbEUeS4&t=4s
https://learn.udacity.com/nanodegrees/nd002/parts/cd0005/lessons/ls12054/concepts/e6b40b94-1eb5-42cf-bd47-46be878cd2ef
https://www.geeksforgeeks.org/how-to-combine-two-dataframe-in-python-pandas/
https://data.library.virginia.edu/logistic-regression-four-ways-with-python/#:~:text=Quick%20Summary%20of%20the%20Logistic%20Regression%20Process&text=Split%20the%20dataset%20into%20training,the%20model%20from%20these%20predictions
